# teleop_offboard_attitude
A teleoperation ROS Node for manually controlling a multirotor aircraft
